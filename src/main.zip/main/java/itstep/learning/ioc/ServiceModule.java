package itstep.learning.ioc;

import com.google.inject.AbstractModule;

public class ServiceModule extends AbstractModule {
    @Override
    protected void configure() {
        super.configure();
    }
}
